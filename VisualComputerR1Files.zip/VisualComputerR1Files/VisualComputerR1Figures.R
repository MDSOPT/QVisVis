#Remove existing data
rm(list=ls())

#Required libraries
if (!require("dimRed")) install.packages("dimRed")
library(dimRed)
if (!require("smacof")) install.packages("smacof")
library(smacof)
if (!require("kernlab")) install.packages("kernlab")
library(kernlab)
if (!require("lle")) install.packages("lle")
library(lle)
if (!require("vegan")) install.packages("vegan")
library(vegan)
if (!require("diffusionMap")) install.packages("diffusionMap")
library(diffusionMap)
if (!require("Rtsne")) install.packages("Rtsne")
library(Rtsne)
if (!require("umap")) install.packages("umap")
library(umap)
if (!require("DMwR")) install.packages("DMwR")
library(DMwR)
if (!require("ggplot2")) install.packages("ggplot2")
library(ggplot2)
if (!require("gridExtra")) install.packages("gridExtra")
library(gridExtra)
if (!require("grid")) install.packages("grid")
library(grid)
if (!require("seriation")) install.packages("seriation")
library(seriation)

#Create manifolds and visualizations
source('~/R/GenAgree/3DCode.R')
Sphere1<-sphere(1000,10)
Torus1<-torus(1000,10,1)
Torus2<-torus(1000,1,10)
SwissRoll1<-swissroll(1000,3,0,10)
RegSphere1<-rsphere(pi/22,10)
RegTorus1<-rtorus(pi/16, pi/16, 10, 1)
RegTorus2<-rtorus(pi/16, pi/16, 1, 10)

#Create the distances between the manifolds
DSphere1<-as.matrix(dist(Sphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
DTorus1<-as.matrix(dist(Torus1, method = 'euclidean', diag = TRUE, upper = TRUE))
DTorus2<-as.matrix(dist(Torus2, method = 'euclidean', diag = TRUE, upper = TRUE))
DSwissRoll1<-as.matrix(dist(SwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
DRegSphere1<-as.matrix(dist(RegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
DRegTorus1<-as.matrix(dist(RegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
DRegTorus2<-as.matrix(dist(RegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))


#Run smacof using smacof library
fit.sym <- smacofSym(dist(Sphere1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofSphere1<-fit.sym$conf
fit.sym <- smacofSym(dist(Torus1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofTorus1<-fit.sym$conf
fit.sym <- smacofSym(dist(Torus2, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofTorus2<-fit.sym$conf
fit.sym <- smacofSym(dist(SwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofSwissRoll1<-fit.sym$conf
fit.sym <- smacofSym(dist(RegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofRegSphere1<-fit.sym$conf
fit.sym <- smacofSym(dist(RegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofRegTorus1<-fit.sym$conf
fit.sym <- smacofSym(dist(RegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="ratio")
YSmacofRegTorus2<-fit.sym$conf
rm(fit.sym)

#Create distances for smacof
D<-as.matrix(dist(YSmacofSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="Sphere1")
D<-as.matrix(dist(YSmacofTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="Torus1")
D<-as.matrix(dist(YSmacofTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="Torus2")
D<-as.matrix(dist(YSmacofSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="SwissRoll1")
D<-as.matrix(dist(YSmacofRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="RegSphere1")
D<-as.matrix(dist(YSmacofRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="RegTorus1")
D<-as.matrix(dist(YSmacofRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="RegTorus2")


# #Smacof with spline fitting (not used revision 1)
# fit.sym <- smacofSym(dist(Sphere1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLSphere1<-fit.sym$conf
# fit.sym <- smacofSym(dist(Torus1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLTorus1<-fit.sym$conf
# fit.sym <- smacofSym(dist(Torus2, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLTorus2<-fit.sym$conf
# fit.sym <- smacofSym(dist(SwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLSwissRoll1<-fit.sym$conf
# fit.sym <- smacofSym(dist(RegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLRegSphere1<-fit.sym$conf
# fit.sym <- smacofSym(dist(RegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLRegTorus1<-fit.sym$conf
# fit.sym <- smacofSym(dist(RegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE), ndim = 2,type="mspline")
# YSmacofSPLRegTorus2<-fit.sym$conf
# rm(fit.sym)
# 
# D<-as.matrix(dist(YSmacofSPLSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="Sphere1")
# D<-as.matrix(dist(YSmacofSPLTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="Torus1")
# D<-as.matrix(dist(YSmacofSPLTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="Torus2")
# D<-as.matrix(dist(YSmacofSPLSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="SwissRoll1")
# D<-as.matrix(dist(YSmacofSPLRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLRegSphere<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="RegSphere1")
# D<-as.matrix(dist(YSmacofSPLRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="RegTorus1")
# D<-as.matrix(dist(YSmacofSPLRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgSmacofSPLRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofSPL",DataDescription="RegTorus2")

#Our "heruistic version of local MDS.  compare with tSNE
PropKeep<-0.1
D<-as.matrix(dist(Sphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCSphere1<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

D<-as.matrix(dist(Torus1, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCTorus1<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

D<-as.matrix(dist(Torus2, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCTorus2<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

PropKeep<-0.1
D<-as.matrix(dist(SwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCSwissRoll1<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

PropKeep<-0.1
D<-as.matrix(dist(RegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCRegSphere1<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

PropKeep<-0.1
D<-as.matrix(dist(RegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCRegTorus1<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

PropKeep<-0.1
D<-as.matrix(dist(RegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
MaxDist<-quantile(D,PropKeep)
W<-(D<MaxDist)
mode(W)<-"numeric"
YSmacofLOCRegTorus2<-smacofSym(D, ndim = 2,type="ratio",weightmat=W)$conf

D<-as.matrix(dist(YSmacofLOCRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="Sphere1")
D<-as.matrix(dist(YSmacofLOCTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="Torus1")
D<-as.matrix(dist(YSmacofLOCTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="Torus2")
D<-as.matrix(dist(YSmacofLOCSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="SwissRoll1")
D<-as.matrix(dist(YSmacofLOCRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="RegSphere1")
D<-as.matrix(dist(YSmacofLOCRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="RegTorus1")
D<-as.matrix(dist(YSmacofLOCRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofLOCRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="SmacofLOC",DataDescription="RegTorus2")

#Princiapal component analysis using base libraries
YPCASphere1<-princomp(Sphere1)$scores[,1:2]
YPCATorus1<-princomp(Torus1)$scores[,1:2]
YPCATorus2<-princomp(Torus2)$scores[,1:2]
YPCASwissRoll1<-princomp(SwissRoll1)$scores[,1:2]
YPCARegSphere1<-princomp(RegSphere1)$scores[,1:2]
YPCARegTorus1<-princomp(RegTorus1)$scores[,1:2]
YPCARegTorus2<-princomp(RegTorus2)$scores[,1:2]

D<-as.matrix(dist(YPCASphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCASphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="Sphere1")
D<-as.matrix(dist(YPCATorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCATorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="Torus1")
D<-as.matrix(dist(YPCATorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCATorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="Torus2")
D<-as.matrix(dist(YPCASwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCASwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="SwissRoll1")
D<-as.matrix(dist(YPCARegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCARegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="RegSphere1")
D<-as.matrix(dist(YPCARegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCARegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="RegTorus1")
D<-as.matrix(dist(YPCARegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCARegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="RegTorus2")

#Diffusion mapping using default parameters
library(diffusionMap)
YDMapSphere1<-diffuse(dist(Sphere1, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X
YDMapTorus1<-diffuse(dist(Torus1, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X
YDMapTorus2<-diffuse(dist(Torus2, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X
YDMapSwissRoll1<-diffuse(dist(SwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X
YDMapRegSphere1<-diffuse(dist(RegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X
YDMapRegTorus1<-diffuse(dist(RegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X
YDMapRegTorus2<-diffuse(dist(RegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE),neigen = 2)$X

D<-as.matrix(dist(YDMapSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="Sphere1")
D<-as.matrix(dist(YDMapTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="Torus1")
D<-as.matrix(dist(YDMapTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="Torus2")
D<-as.matrix(dist(YDMapSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="SwissRoll1")
D<-as.matrix(dist(YDMapRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="RegSphere1")
D<-as.matrix(dist(YDMapRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="RegTorus1")
D<-as.matrix(dist(YDMapRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgDMapRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="DiffMap",DataDescription="RegTorus2")

# #Kernal PCA - using kernlab.  Removed for revision 1 of the paper
# YkPCASphere1<-kpca(Sphere1, kernel = "rbfdot")@xmatrix[,1:2]
# YkPCATorus1<-kpca(Torus1, kernel = "rbfdot")@xmatrix[,1:2]
# YkPCATorus2<-kpca(Torus2, kernel = "rbfdot")@xmatrix[,1:2]
# YkPCASwissRoll1<-kpca(SwissRoll1, kernel = "rbfdot")@xmatrix[,1:2]
# YkPCARegSphere1<-kpca(RegSphere1, kernel = "rbfdot")@xmatrix[,1:2]
# YkPCARegTorus1<-kpca(RegTorus1, kernel = "rbfdot")@xmatrix[,1:2]
# YkPCARegTorus2<-kpca(RegTorus2, kernel = "rbfdot")@xmatrix[,1:2]
# 
# D<-as.matrix(dist(YkPCASphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCASphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="Sphere1")
# D<-as.matrix(dist(YkPCATorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCATorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="Torus1")
# D<-as.matrix(dist(YkPCATorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCATorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="Torus2")
# D<-as.matrix(dist(YkPCASwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCASwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="SwissRoll1")
# D<-as.matrix(dist(YkPCARegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCARegSphere<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="RegSphere1")
# D<-as.matrix(dist(YkPCARegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCARegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="RegTorus1")
# D<-as.matrix(dist(YkPCARegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
# AgkPCARegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="KernPCA",DataDescription="RegTorus2")


#Run lle using the lle library
Bestk<-calc_k(Sphere1,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(Sphere1, 2, k)
YLLESphere1<-lle.res$Y

Bestk<-calc_k(Torus1,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(Torus1, 2, k)
YLLETorus1<-lle.res$Y

Bestk<-calc_k(Torus2,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(Torus2, 2, k)
YLLETorus2<-lle.res$Y

Bestk<-calc_k(SwissRoll1,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(SwissRoll1, 2, k)
YLLESwissRoll1<-lle.res$Y

Bestk<-calc_k(RegSphere1,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(RegSphere1, 2, k)
YLLERegSphere1<-lle.res$Y

Bestk<-calc_k(RegTorus1,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(RegTorus1, 2, k)
YLLERegTorus1<-lle.res$Y

Bestk<-calc_k(RegTorus2,2, kmin=1, kmax=20, plotres=TRUE, parallel=FALSE, cpus=2, iLLE=FALSE)
k<-which(Bestk[,2]==min(Bestk[,2]))
lle.res<-lle(RegTorus2, 2, k)
YLLERegTorus2<-lle.res$Y
rm(Bestk,k,lle.res)

D<-as.matrix(dist(YLLESphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLESphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="Sphere1")
D<-as.matrix(dist(YLLETorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLETorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="Torus1")
D<-as.matrix(dist(YLLETorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLETorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="Torus2")
D<-as.matrix(dist(YLLESwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLESwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="SwissRoll1")
D<-as.matrix(dist(YLLERegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLERegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="RegSphere1")
D<-as.matrix(dist(YLLERegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLERegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="RegTorus1")
D<-as.matrix(dist(YLLERegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgLLERegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="LLE",DataDescription="RegTorus2")

#Now run the isomap using the vegan library
YIsoSphere1<-isomap(dist(Sphere1, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points
YIsoTorus1<-isomap(dist(Torus1, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points
YIsoTorus2<-isomap(dist(Torus2, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points
YIsoSwissRoll1<-isomap(dist(SwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points
YIsoRegSphere1<-isomap(dist(RegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points
YIsoRegTorus1<-isomap(dist(RegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points
YIsoRegTorus2<-isomap(dist(RegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE),ndim=2,k=30)$points

D<-as.matrix(dist(YIsoSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="Sphere1")
D<-as.matrix(dist(YIsoTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="Torus1")
D<-as.matrix(dist(YIsoTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="Torus2")
D<-as.matrix(dist(YIsoSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="SwissRoll1")
D<-as.matrix(dist(YIsoRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="RegSphere1")
D<-as.matrix(dist(YIsoRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="RegTorus1")
D<-as.matrix(dist(YIsoRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgIsoRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="RegTorus2")



#Laplacian eigenmaps from library dimRed
leim <- LaplacianEigenmaps() 
InData<-dimRedData(as.data.frame(Sphere1))
YLAPSphere1 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)

InData<-dimRedData(as.data.frame(Torus1))
YLAPTorus1 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)

InData<-dimRedData(as.data.frame(Torus2))
YLAPTorus2 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)

InData<-dimRedData(as.data.frame(SwissRoll1))
YLAPSwissRoll1 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)

InData<-dimRedData(as.data.frame(RegSphere1))
YLAPRegSphere1 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)

InData<-dimRedData(as.data.frame(RegTorus1))
YLAPRegTorus1 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)

InData<-dimRedData(as.data.frame(RegTorus2))
YLAPRegTorus2 <- as.data.frame(leim@fun(InData, leim@stdpars)@data)
rm(InData,leim)

D<-as.matrix(dist(YLAPSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="Sphere1")
D<-as.matrix(dist(YLAPTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="Torus1")
D<-as.matrix(dist(YLAPTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="Torus2")
D<-as.matrix(dist(YLAPSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="SwissRoll1")
D<-as.matrix(dist(YLAPRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="RegSphere1")
D<-as.matrix(dist(YLAPRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="RegTorus1")
D<-as.matrix(dist(YLAPRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgYLAPRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="LapEigen",DataDescription="RegTorus2")

#Run tSNE with default parameterizations from the libray r
YtsneSphere1<-Rtsne(Sphere1,dims = 2,theta=0,check_duplicates = FALSE)$Y
YtsneTorus1<-Rtsne(Torus1,dims = 2,theta=0,check_duplicates = FALSE)$Y
YtsneTorus2<-Rtsne(Torus1,dims = 2,theta=0,check_duplicates = FALSE)$Y
YtsneSwissRoll1<-Rtsne(SwissRoll1,dims = 2,theta=0,check_duplicates = FALSE)$Y
YtsneRegSphere1<-Rtsne(RegSphere1,dims = 2,theta=0,check_duplicates = FALSE)$Y
YtsneRegTorus1<-Rtsne(RegTorus1,dims = 2,theta=0,check_duplicates = FALSE)$Y
YtsneRegTorus2<-Rtsne(RegTorus2,dims = 2,theta=0,check_duplicates = FALSE)$Y

D<-as.matrix(dist(YtsneSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="Sphere1")
D<-as.matrix(dist(YtsneTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="Torus1")
D<-as.matrix(dist(YtsneTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="Torus2")
D<-as.matrix(dist(YtsneSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="SwissRoll1")
D<-as.matrix(dist(YtsneRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="RegSphere1")
D<-as.matrix(dist(YtsneRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="RegTorus1")
D<-as.matrix(dist(YtsneRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="RegTorus2")

#Run using umap from the umap library using default settings
YumapSphere1<-umap(Sphere1,config = umap.defaults, method = "naive")$layout
YumapTorus1<-umap(Torus1,config = umap.defaults, method = "naive")$layout
YumapTorus2<-umap(Torus2,config = umap.defaults, method = "naive")$layout
YumapSwissRoll1<-umap(SwissRoll1,config = umap.defaults, method = "naive")$layout
YumapRegSphere1<-umap(RegSphere1,config = umap.defaults, method = "naive")$layout
YumapRegTorus1<-umap(RegTorus1,config = umap.defaults, method = "naive")$layout
YumapRegTorus2<-umap(RegTorus2,config = umap.defaults, method = "naive")$layout

D<-as.matrix(dist(YumapSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapSphere1<-GenAgreeDist(DSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="Sphere1")
D<-as.matrix(dist(YumapTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapTorus1<-GenAgreeDist(DTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="Torus1")
D<-as.matrix(dist(YumapTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapTorus2<-GenAgreeDist(DTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="Torus2")
D<-as.matrix(dist(YumapSwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapSwissRoll1<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="SwissRoll1")
D<-as.matrix(dist(YumapRegSphere1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapRegSphere1<-GenAgreeDist(DRegSphere1,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="RegSphere1")
D<-as.matrix(dist(YumapRegTorus1, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapRegTorus1<-GenAgreeDist(DRegTorus1,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="RegTorus1")
D<-as.matrix(dist(YumapRegTorus2, method = 'euclidean', diag = TRUE, upper = TRUE))
AgumapRegTorus2<-GenAgreeDist(DRegTorus2,D,1,999,ProxMode='dis',SymMode='sym',Description="UMAP",DataDescription="RegTorus2")


#Consumer Example
YPS<-read.csv("YPS2.csv",header=TRUE)
str(YPS, list.len=ncol(YPS))
YPSPref<-YPS[,1:135]
YPSDem<-YPS[,136:145]
YPSPref2<-knnImputation(YPSPref, scale = F)
Dist<-dist(YPSPref2,method="euclidean",diag = TRUE, upper = TRUE)

YtsneYPS5<-Rtsne(YPSPref2, perplexity=5,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS5, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS5<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE5",DataDescription="YPSLens")

YtsneYPS10<-Rtsne(YPSPref2, perplexity=10,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS10, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS10<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE10",DataDescription="YPSLens")

YtsneYPS20<-Rtsne(YPSPref2, perplexity=20,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS20, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS20<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE20",DataDescription="YPSLens")

YtsneYPS50<-Rtsne(YPSPref2, perplexity=50,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS50, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS50<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE50",DataDescription="YPSLens")

YtsneYPS100<-Rtsne(YPSPref2, perplexity=100,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS100, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS100<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE100",DataDescription="YPSLens")

YtsneYPS200<-Rtsne(YPSPref2, perplexity=200,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS200, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS200<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE200",DataDescription="YPSLens")

YtsneYPS336<-Rtsne(YPSPref2, perplexity=336,dims = 2,theta=0)$Y
D<-as.matrix(dist(YtsneYPS336, method = 'euclidean', diag = TRUE, upper = TRUE))
AgtsneYPS336<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="t-SNE336",DataDescription="YPSLens")


#Let's also go through the different types of Smacof
YSmacofRatioYPS<- smacofSym(Dist, ndim = 2,type="ratio")$conf
D<-as.matrix(dist(YSmacofRatioYPS, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofRatioYPS<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="YPSLens")

YSmacofOrdinalYPS<- smacofSym(Dist, ndim = 2,type="ordinal")$conf
D<-as.matrix(dist(YSmacofOrdinalYPS, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofOrdinalYPS<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="YPSLens")

YSmacofSplineYPS<- smacofSym(Dist, ndim = 2,type="mspline")$conf
D<-as.matrix(dist(YSmacofSplineYPS, method = 'euclidean', diag = TRUE, upper = TRUE))
AgSmacofSplineYPS<-GenAgreeDist(as.matrix(Dist),D,1,1009,ProxMode='dis',SymMode='sym',Description="Smacof",DataDescription="YPSLens")

rm(D,Dist)

#Load in the 128 dimension dataset
Cluster128<-read.csv("dim128.csv",header=TRUE)
Dist<-dist(Cluster128[,-1],method="euclidean",diag = TRUE, upper = TRUE)

tsnepCluster128<-list()
Iter<-1
pList<-seq(5,100,5)
for (Inp in pList)
{
  YtsnepCluster128<-Rtsne(Cluster128[,-1], perplexity=Inp,dims = 2,theta=0,check_duplicates = FALSE)$Y
  D<-as.matrix(dist(YtsnepCluster128, method = 'euclidean', diag = TRUE, upper = TRUE))
  AgtsnepCluster128<-GenAgreeDist(as.matrix(Dist),D,1,1023,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="Cluster128")
  tsnepCluster128[[Iter]]<-list(InParam=Inp,Dest=YtsnepCluster128,AgreeStruct=AgtsnepCluster128)
  Iter<-Iter+1
}
#Carry out principal components analysis
YPCACluster128<-princomp(Cluster128[,-1])$scores[,1:2]
D<-as.matrix(dist(YPCACluster128, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCACluster128<-GenAgreeDist(as.matrix(Dist),D,1,1023,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="Cluster128")


rm(Iter,pList,Inp,YtsnepCluster128,Dist,AgtsnepCluster128)

#Parameter tuning for Isomap
IsokSwissRoll<-list()
Iter<-1
kList<-seq(5,100,5)
for (Ink in kList)
{
  YIsokSwissRoll<-isomap(DSwissRoll1,ndim=2,k=Ink)$points
  D<-as.matrix(dist(YIsokSwissRoll, method = 'euclidean', diag = TRUE, upper = TRUE))
  AgIsokSwissRoll<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="Isomap",DataDescription="SwissRoll1")
  IsokSwissRoll[[Iter]]<-list(InParam=Ink,Dest=YIsokSwissRoll,AgreeStruct=AgIsokSwissRoll)
  Iter<-Iter+1
}
rm(Iter)
rm(Ink)
rm(YIsokSwissRoll)
rm(AgIsokSwissRoll)
rm(kList)

tsenkSwissRoll<-list()
Iter<-1
PList<-seq(5,100,5)
for (Inp in PList)
{
  YtsenkSwissRoll<-Rtsne(SwissRoll1, perplexity=Inp,dims = 2,theta=0)$Y
  D<-as.matrix(dist(YtsenkSwissRoll, method = 'euclidean', diag = TRUE, upper = TRUE))
  AgtsenkSwissRoll<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="SwissRoll1")
  tsenkSwissRoll[[Iter]]<-list(InParam=Inp,Dest=YtsenkSwissRoll,AgreeStruct=AgtsenkSwissRoll)
  Iter<-Iter+1
}
rm(Iter)
rm(Ink)
rm(YIsokSwissRoll)
rm(AgIsokSwissRoll)
rm(kList)

tsenkSwissRoll<-list()
Iter<-1
PList<-seq(5,100,5)
for (Inp in PList)
{
  YtsenkSwissRoll<-Rtsne(SwissRoll1, perplexity=Inp,dims = 2,theta=0)$Y
  D<-as.matrix(dist(YtsenkSwissRoll, method = 'euclidean', diag = TRUE, upper = TRUE))
  AgtsenkSwissRoll<-GenAgreeDist(DSwissRoll1,D,1,999,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="SwissRoll1")
  tsenkSwissRoll[[Iter]]<-list(InParam=Inp,Dest=YtsenkSwissRoll,AgreeStruct=AgtsenkSwissRoll)
  Iter<-Iter+1
}
tsenkSwissRoll[[1]]$ParamName<-"p"

tsenkConsumer<-list()
Iter<-1
PList<-seq(5,100,5)
for (Inp in PList)
{
  YtsenkConsumer<-Rtsne(YPSPref2, perplexity=Inp,dims = 2,theta=0)$Y
  D<-as.matrix(dist(YtsenkConsumer, method = 'euclidean', diag = TRUE, upper = TRUE))
  AgtsenkConsumer<-GenAgreeDist(as.matrix(Dist),D,1,250,ProxMode='dis',SymMode='sym',Description="t-SNE",DataDescription="Consumer Dataset")
  tsenkConsumer[[Iter]]<-list(InParam=Inp,Dest=YtsenkConsumer,AgreeStruct=AgtsenkConsumer)
  Iter<-Iter+1
}


rm(Iter)
rm(Ink)
rm(YIsokSwissRoll)
rm(AgIsokSwissRoll)
rm(kList)

#Load in the fashion dataset
FashionDS<-read.csv("fashion-mnist_test.csv",stringsAsFactors = TRUE)
dim(FashionDS)
levels(FashionDS[,1]) #Check that the categorical variables have come through as factors

#Run a PCA for the dataset
YPCAFashion<-princomp(FashionDS[,-1])$scores[,1:2]
Dist<-dist(FashionDS[,-1], method = 'euclidean', diag = TRUE, upper = TRUE)
D<-as.matrix(dist(YPCAFashion, method = 'euclidean', diag = TRUE, upper = TRUE))
AgPCAFashion<-GenAgreeDist(as.matrix(Dist),D,1,100,ProxMode='dis',SymMode='sym',Description="PCA",DataDescription="Fashion")

#Now run a tSNE for the dataset
YtsneFashion<-Rtsne(FashionDS[,-1], dims = 2,theta=0,check_duplicates = FALSE)$Y


##Figure 1
par(mfrow=c(3,2))
ScatterCompare3D(AgumapSphere1,AgPCASphere1,Sphere1,IsBorder=FALSE,ColMode="binary",cex.lab=1.5,cex.main=2,cex.axis=1,Startk=1,Endk=100)
ScatterCompare3D(AgumapTorus2,AgPCATorus2,Torus2,IsBorder=FALSE,ColMode="binary",cex.lab=1.5,cex.main=2,cex.axis=1,Startk=1,Endk=100)
ScatterCompare3D(AgumapSwissRoll1,AgPCASwissRoll1,SwissRoll1,IsBorder=FALSE,ColMode="binary",cex.lab=1.5,cex.main=2,cex.axis=1,Startk=1,Endk=100)
ScatterCompare3D(AgumapRegSphere1,AgPCARegSphere1,RegSphere1,IsBorder=FALSE,ColMode="binary",cex.lab=1.5,cex.main=2,cex.axis=1,Startk=1,Endk=100)
ScatterCompare3D(AgumapRegTorus1,AgPCARegTorus1,RegTorus1,IsBorder=FALSE,ColMode="binary",cex.lab=1.5,cex.main=2,cex.axis=1,Startk=1,Endk=100)
ScatterCompare3D(AgumapRegTorus2,AgPCARegTorus2,RegTorus2,IsBorder=FALSE,ColMode="binary",cex.lab=1.5,cex.main=2,cex.axis=1,Startk=1,Endk=100)

dev.off()
#Figure 2 - Sphere scatterplots
p1<-ScatterComparegg(AgSmacofSphere1,AgPCASphere1,YSmacofSphere1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p2<-ScatterComparegg(AgtsneSphere1,AgPCASphere1,YtsneSphere1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p3<-ScatterComparegg(AgLLESphere1,AgPCASphere1,YLLESphere1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p4<-ScatterComparegg(AgYLAPSphere1,AgPCASphere1,YLAPSphere1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p5<-ScatterComparegg(AgDMapSphere1,AgPCASphere1,YDMapSphere1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p6<-ScatterComparegg(AgumapSphere1,AgPCASphere1,YumapSphere1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2,top =textGrob("Scatterplots for Sphere", gp=gpar(fontsize=18,fontface="bold")))

#Figure 3 - Sphere Scatterplots for k = 1 to 10
p1<-ScatterComparegg(AgSmacofSphere1,AgPCASphere1,YSmacofSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p2<-ScatterComparegg(AgtsneSphere1,AgPCASphere1,YtsneSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p3<-ScatterComparegg(AgLLESphere1,AgPCASphere1,YLLESphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p4<-ScatterComparegg(AgYLAPSphere1,AgPCASphere1,YLAPSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p5<-ScatterComparegg(AgDMapSphere1,AgPCASphere1,YDMapSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p6<-ScatterComparegg(AgumapSphere1,AgPCASphere1,YumapSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = textGrob("Scatterplots for Sphere: k=1 to 10",gp=gpar(fontsize=18,fontface="bold")))

#Figure 4 - SwissRoll scatterplots
p1<-ScatterComparegg(AgSmacofSwissRoll1,AgPCASwissRoll1,YSmacofSwissRoll1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p2<-ScatterComparegg(AgtsneSwissRoll1,AgPCASwissRoll1,YtsneSwissRoll1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p3<-ScatterComparegg(AgLLESwissRoll1,AgPCASwissRoll1,YLLESwissRoll1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p4<-ScatterComparegg(AgYLAPSwissRoll1,AgPCASwissRoll1,YLAPSwissRoll1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p5<-ScatterComparegg(AgDMapSwissRoll1,AgPCASwissRoll1,YDMapSwissRoll1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p6<-ScatterComparegg(AgumapSwissRoll1,AgPCASwissRoll1,YumapSwissRoll1,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2,top =textGrob("Scatterplots for SwissRoll", gp=gpar(fontsize=18,fontface="bold")))

#Figure 5 - SwissRoll Scatterplots for k = 1 to 10
p1<-ScatterComparegg(AgSmacofSwissRoll1,AgPCASwissRoll1,YSmacofSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p2<-ScatterComparegg(AgtsneSwissRoll1,AgPCASwissRoll1,YtsneSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p3<-ScatterComparegg(AgLLESwissRoll1,AgPCASwissRoll1,YLLESwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p4<-ScatterComparegg(AgYLAPSwissRoll1,AgPCASwissRoll1,YLAPSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p5<-ScatterComparegg(AgDMapSwissRoll1,AgPCASwissRoll1,YDMapSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
p6<-ScatterComparegg(AgumapSwissRoll1,AgPCASwissRoll1,YumapSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="none",ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = textGrob("Scatterplots for SwissRoll: k=1 to 10",gp=gpar(fontsize=18,fontface="bold")))

#Figure 6: Regular Toras t-SNE/UMAP vs. PCA
p1<-HMapComparegg(AgtsneRegTorus2,AgPCARegTorus2,ColMode="enhanced",TextSize=15)
p2<-HMapComparegg(AgumapRegTorus2,AgPCARegTorus2,ColMode="enhanced",TextSize=15)
grid.arrange(p1, p2, ncol = 2, top = textGrob("Heatmaps for Regular Torus 2",gp=gpar(fontsize=18,fontface="bold")))

#Figure 7: Swiss roll UMAP vs. PCA
#First use seriation library to order the data
order <- seriate(dist(YLLESwissRoll1, method = 'euclidean', diag = TRUE, upper = TRUE),method="ARSA")
p1<-HMapComparegg(AgtsneSwissRoll1,AgPCASwissRoll1,ColMode="enhanced",TextSize=15,Ordering=unlist(order))
p2<-HMapComparegg(AgumapSwissRoll1,AgPCASwissRoll1,ColMode="enhanced",TextSize=15,Ordering=unlist(order))
grid.arrange(p1, p2, ncol = 2, top = textGrob("Heatmaps for Swiss Roll",gp=gpar(fontsize=18,fontface="bold")))

#Figure 8: Category based heatmap
YtsneFashion<-Rtsne(FashionDS[,-1], dims = 2,theta=0,check_duplicates = FALSE)$Y
CatOutputs<-CategoryAgreeTableCompare(YtsneFashion,YPCAFashion,FashionDS[,-1],FashionDS[,1],Startk=1,Endk=100,Description1="t-SNE",Description2="PCA",DataDescription="Fashion")
HMapCategoryTableComparegg(CatOutputs,PlotMode="adjusted",LowCol="darkred",MidCol="white",HighCol="darkblue",ShowMode="show",TextSize=18)


#Figure 9: Sphere (LLE, tsne, umap) vs. PCA (k=1:10) and Sphere (Smacof, tsne, umap) vs. PCA (all k)
p1<-ScatterComparegg(AgLLERegSphere1,AgPCARegSphere1,YLLERegSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return",TextSize=15)
p2<-ScatterComparegg(AgLLERegSphere1,AgPCARegSphere1,YLLERegSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return",TextSize=15)
p3<-ScatterComparegg(AgtsneRegSphere1,AgPCARegSphere1,YtsneRegSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return",TextSize=15)
p4<-ScatterComparegg(AgtsneRegSphere1,AgPCARegSphere1,YtsneRegSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return",TextSize=15)
p5<-ScatterComparegg(AgumapRegSphere1,AgPCARegSphere1,YumapRegSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return",TextSize=15)
p6<-ScatterComparegg(AgumapRegSphere1,AgPCARegSphere1,YumapRegSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = textGrob("Scatterplots with Loess for Regular Sphere",gp=gpar(fontsize=18,fontface="bold")))

#Figure 10: Lift diagrams for the Swiss Roll/Sphere 
p1<-PLiftComparegg(AgSmacofSwissRoll1,AgPCASwissRoll1,ShowMode="return",TextSize=15)
p2<-PLiftComparegg(AgtsneSwissRoll1,AgPCASwissRoll1,ShowMode="return",TextSize=15)
p3<-PLiftComparegg(AgLLESwissRoll1,AgPCASwissRoll1,ShowMode="return",TextSize=15)
p4<-PLiftComparegg(AgYLAPSwissRoll1,AgPCASwissRoll1,ShowMode="return",TextSize=15)
p5<-PLiftComparegg(AgDMapSwissRoll1,AgPCASwissRoll1,ShowMode="return",TextSize=15)
p6<-PLiftComparegg(AgumapSwissRoll1,AgPCASwissRoll1,ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = textGrob("Lift for Swiss Roll",gp=gpar(fontsize=18,fontface="bold")))
p1<-PLiftComparegg(AgSmacofSphere1,AgPCASphere1,ShowMode="return",TextSize=15)
p2<-PLiftComparegg(AgtsneSphere1,AgPCASphere1,ShowMode="return",TextSize=15)
p3<-PLiftComparegg(AgLLESphere1,AgPCASphere1,ShowMode="return",TextSize=15)
p4<-PLiftComparegg(AgYLAPSphere1,AgPCASphere1,ShowMode="return",TextSize=15)
p5<-PLiftComparegg(AgDMapSphere1,AgPCASphere1,ShowMode="return",TextSize=15)
p6<-PLiftComparegg(AgumapSphere1,AgPCASphere1,ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = textGrob("Lift for Sphere",gp=gpar(fontsize=18,fontface="bold")))

#Figure 11: Lift for consumer example
p1<-PLiftComparegg(AgtsneYPS5,AgSmacofOrdinalYPS,ShowMode="return",TextSize=15)
p2<-PLiftComparegg(AgtsneYPS10,AgSmacofOrdinalYPS,ShowMode="return",TextSize=15)
p3<-PLiftComparegg(AgtsneYPS50,AgSmacofOrdinalYPS,ShowMode="return",TextSize=15)
p4<-PLiftComparegg(AgtsneYPS100,AgSmacofOrdinalYPS,ShowMode="return",TextSize=15)
p5<-PLiftComparegg(AgtsneYPS200,AgSmacofOrdinalYPS,ShowMode="return",TextSize=15)
p6<-PLiftComparegg(AgtsneYPS336,AgSmacofOrdinalYPS,ShowMode="return",TextSize=15)
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = textGrob("Lift for Consumer Dataset: t-SNE vs. Ordinal Smacof",gp=gpar(fontsize=18,fontface="bold")))

#Figure 12: Heatmap comparison for t-SNE vs. Smacof
orderConsumer <- seriate(dist(YPSPref2, method = 'euclidean', diag = TRUE, upper = TRUE),method="ARSA")
p1<-HMapComparegg(AgtsneYPS5,AgSmacofOrdinalYPS,ColMode="enhanced",TextSize=15,Ordering=unlist(orderConsumer))
p2<-HMapComparegg(AgtsneYPS336,AgSmacofOrdinalYPS,ColMode="enhanced",TextSize=15,Ordering=unlist(orderConsumer))
grid.arrange(p1, p2, ncol = 2, top = textGrob("Consumer Dataset Heatmaps: t-SNE vs. Ordinal Smacof",gp=gpar(fontsize=18,fontface="bold")))


#Removed/Other Paper Visualizations
p1<-ScatterComparegg(AgSmacofSphere1,AgPCASphere1,YSmacofSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p2<-ScatterComparegg(AgkPCASphere1,AgPCASphere1,YPCASphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p3<-ScatterComparegg(AgLLESphere1,AgPCASphere1,YLLESphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p4<-ScatterComparegg(AgYLAPSphere1,AgPCASphere1,YLAPSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p5<-ScatterComparegg(AgDMapSphere1,AgPCASphere1,YDMapSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p6<-ScatterComparegg(AgSmacofLOCSphere1,AgPCASphere1,YSmacofLOCSphere1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = "Scatterplots for Sphere: k=1 to 10")

p1<-ScatterComparegg(AgSmacofSphere1,AgPCASphere1,YSmacofSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p2<-ScatterComparegg(AgkPCASphere1,AgPCASphere1,YPCASphere1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p3<-ScatterComparegg(AgLLESphere1,AgPCASphere1,YLLESphere1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p4<-ScatterComparegg(AgYLAPSphere1,AgPCASphere1,YLAPSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p5<-ScatterComparegg(AgDMapSphere1,AgPCASphere1,YDMapSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p6<-ScatterComparegg(AgSmacofLOCSphere1,AgPCASphere1,YSmacofLOCSphere1,PlotMode="compare",GradientMode="loess",ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = "Scatterplots for Sphere")

p1<-ScatterComparegg(AgSmacofSwissRoll1,AgPCASwissRoll1,YSmacofSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p2<-ScatterComparegg(AgkPCASwissRoll1,AgPCASwissRoll1,YPCASwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p3<-ScatterComparegg(AgLLESwissRoll1,AgPCASwissRoll1,YLLESwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p4<-ScatterComparegg(AgYLAPSwissRoll1,AgPCASwissRoll1,YLAPSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p5<-ScatterComparegg(AgDMapSwissRoll1,AgPCASwissRoll1,YDMapSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
p6<-ScatterComparegg(AgSmacofLOCSwissRoll1,AgPCASwissRoll1,YSmacofLOCSwissRoll1,Startk=1,Endk=10,PlotMode="compare",GradientMode="loess",ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = "Scatterplots for SwissRoll: k=1 to 10")


p1<-ScatterComparegg(AgSmacofSwissRoll1,AgPCASwissRoll1,YSmacofSwissRoll1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p2<-ScatterComparegg(AgkPCASwissRoll1,AgPCASwissRoll1,YPCASwissRoll1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p3<-ScatterComparegg(AgLLESwissRoll1,AgPCASwissRoll1,YLLESwissRoll1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p4<-ScatterComparegg(AgYLAPSwissRoll1,AgPCASwissRoll1,YLAPSwissRoll1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p5<-ScatterComparegg(AgDMapSwissRoll1,AgPCASwissRoll1,YDMapSwissRoll1,PlotMode="compare",GradientMode="loess",ShowMode="return")
p6<-ScatterComparegg(AgSmacofLOCSwissRoll1,AgPCASwissRoll1,YSmacofLOCSwissRoll1,PlotMode="compare",GradientMode="loess",ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = "Scatterplots for SwissRoll")

p1<-PLiftComparegg(AgSmacofSphere1,AgPCASphere1,ShowMode="return")
p2<-PLiftComparegg(AgkPCASphere1,AgPCASphere1,ShowMode="return")
p3<-PLiftComparegg(AgLLESphere1,AgPCASphere1,ShowMode="return")
p4<-PLiftComparegg(AgYLAPSphere1,AgPCASphere1,ShowMode="return")
p5<-PLiftComparegg(AgDMapSphere1,AgPCASphere1,ShowMode="return")
p6<-PLiftComparegg(AgSmacofLOCSphere1,AgPCASphere1,ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = "Lift for Sphere")

p1<-PLiftComparegg(AgSmacofSwissRoll1,AgPCASwissRoll1,ShowMode="return")
p2<-PLiftComparegg(AgkPCASwissRoll1,AgPCASwissRoll1,ShowMode="return")
p3<-PLiftComparegg(AgLLESwissRoll1,AgPCASwissRoll1,ShowMode="return")
p4<-PLiftComparegg(AgYLAPSwissRoll1,AgPCASwissRoll1,ShowMode="return")
p5<-PLiftComparegg(AgDMapSwissRoll1,AgPCASwissRoll1,ShowMode="return")
p6<-PLiftComparegg(AgSmacofLOCSwissRoll1,AgPCASwissRoll1,ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 2, top = "Lift for SwissRoll")

p1<-PLiftComparegg(AgSmacofRegTorus2,AgPCARegTorus2,ShowMode="return")
p2<-PLiftComparegg(AgkPCARegTorus2,AgPCARegTorus2,ShowMode="return")
p3<-PLiftComparegg(AgLLERegTorus2,AgPCARegTorus2,ShowMode="return")
p4<-PLiftComparegg(AgYLAPRegTorus2,AgPCARegTorus2,ShowMode="return")
p5<-PLiftComparegg(AgDMapRegTorus2,AgPCARegTorus2,ShowMode="return")
p6<-PLiftComparegg(AgSmacofLOCRegTorus2,AgPCARegTorus2,ShowMode="return")
grid.arrange(p1, p2,p3,p4,p5,p6, ncol = 3, top = "Lift for RegTorus")

#Let's build up animation of the Swiss roll over differrent values of k
setwd("~/R/GenAgree/Animated GIFs")
ScatterSingleAnimategg(IsokSwissRoll,Startk=1,Endk=100,PlotMode="simple",ShowMode="save",MatchMode="proc",FileName="Isomap.gif",TitleElements=c(TRUE,FALSE,FALSE,FALSE,FALSE))
setwd("~/R/GenAgree")

setwd("~/R/GenAgree/Animated GIFs")
ScatterSingleAnimategg(IsokSwissRoll,Startk=1,Endk=100,PlotMode="simple",ShowMode="save",MatchMode="procscale",FileName="Isomap2.gif",TitleElements=c(TRUE,FALSE,FALSE,FALSE,FALSE))
setwd("~/R/GenAgree")

#Let's compare isomap with a regular ggplot
setwd("~/R/GenAgree/Animated GIFs")
ScatterCompareAnimategg(IsokSwissRoll,AgSmacofSwissRoll1,Startk=1,Endk=100,PlotMode="increase",ShowMode="save",MatchMode="procscale",FileName="Isomap2.gif",TitleElements=c(TRUE,FALSE,TRUE,TRUE,FALSE),TextSize=15)
setwd("~/R/GenAgree")

setwd("~/R/GenAgree/Animated GIFs")
ScatterCompareAnimategg(tsnepCluster128,AgPCACluster128,Startk=1,Endk=100,PlotMode="increase",ShowMode="save",MatchMode="proc",FileName="Cluster128v2.gif",TitleElements=c(TRUE,FALSE,FALSE,TRUE,FALSE))
setwd("~/R/GenAgree")

#Let's compare isomap with a regular ggplot
setwd("~/R/GenAgree/Animated GIFs")
ScatterCompareAnimategg(tsenkSwissRoll,AgSmacofSwissRoll1,Startk=1,Endk=100,PlotMode="increase",ShowMode="save",MatchMode="procscale",ParamName="p",FileName="t-SNESwissRoll.gif",TitleElements=c(TRUE,FALSE,TRUE,TRUE,FALSE),TextSize=15)
setwd("~/R/GenAgree")

#Let's compare isomap with a regular ggplot
setwd("~/R/GenAgree/Animated GIFs")
ScatterCompareAnimategg(tsenkConsumer,AgSmacofOrdinalYPS,Startk=1,Endk=100,PlotMode="increase",ShowMode="save",MatchMode="procscale",FileName="tSNEConsumer.gif",TitleElements=c(TRUE,FALSE,FALSE,TRUE,FALSE),TextSize=15)
setwd("~/R/GenAgree")

